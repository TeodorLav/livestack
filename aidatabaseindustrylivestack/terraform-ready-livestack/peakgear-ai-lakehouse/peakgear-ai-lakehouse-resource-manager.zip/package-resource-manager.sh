#!/usr/bin/env bash
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUTPUT_ZIP="${1:-$(dirname "${ROOT_DIR}")/peakgear-ai-lakehouse-resource-manager-v22.zip}"

command -v zip >/dev/null 2>&1 || {
  echo "zip is required to build the Resource Manager archive." >&2
  exit 1
}
command -v unzip >/dev/null 2>&1 || {
  echo "unzip is required to verify the Resource Manager archive." >&2
  exit 1
}

mkdir -p "$(dirname "${OUTPUT_ZIP}")"
rm -f "${OUTPUT_ZIP}"

source_files=()
while IFS= read -r -d '' source_file; do
  source_files+=("${source_file}")
done < <(
  find "${ROOT_DIR}" -type f \
    \( -name '*.tf' -o -name '*.yaml' -o -name '*.yml' -o -name '*.json' \
      -o -name '*.md' -o -name '*.txt' -o -name '*.sh' -o -name '*.ps1' \
      -o -name '*.tpl' \) \
    -print0
)

if grep -InE -- '-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----' "${source_files[@]}"; then
  echo "Refusing to package source containing a private key." >&2
  exit 1
fi

non_artifact_files=()
for source_file in "${source_files[@]}"; do
  if [[ "$(basename "${source_file}")" != 'approved-artifacts.json' ]]; then
    non_artifact_files+=("${source_file}")
  fi
done

if grep -InE -- '/p/[A-Za-z0-9_-]{20,}/' "${non_artifact_files[@]}"; then
  echo "Refusing to package source containing an Object Storage pre-authenticated request." >&2
  exit 1
fi

if ! grep -Eq '"peakgear_build_archive_url"[[:space:]]*:[[:space:]]*"https://objectstorage\.us-ashburn-1\.oraclecloud\.com/p/[A-Za-z0-9_-]+/n/c4u04/b/ai-lh-build/o/build_dev\.zip"' "${ROOT_DIR}/approved-artifacts.json"; then
  echo "approved-artifacts.json does not contain the reviewed Peak Gear artifact location." >&2
  exit 1
fi

if ! grep -Eq '"gravitino_archive_url"[[:space:]]*:[[:space:]]*"https://objectstorage\.us-ashburn-1\.oraclecloud\.com/p/[A-Za-z0-9_-]+/n/c4u04/b/ai-lh-build/o/gravitino-iceberg-rest-server-0\.7\.0-incubating-SNAPSHOT-bin\.zip"' "${ROOT_DIR}/approved-artifacts.json"; then
  echo "approved-artifacts.json does not contain the reviewed Gravitino artifact location." >&2
  exit 1
fi

if grep -InE -- 'ocid1\.(tenancy|user|compartment|instance|image|subnet|vcn|networksecuritygroup|autonomousdatabase)\.[A-Za-z0-9._-]{20,}' "${source_files[@]}"; then
  echo "Refusing to package source containing a concrete OCI resource OCID." >&2
  exit 1
fi

if ! grep -Eq 'user_data[[:space:]]*=[[:space:]]*base64gzip[[:space:]]*\(' "${ROOT_DIR}/compute-app.tf"; then
  echo "compute-app.tf must gzip cloud-init user data to remain below the OCI instance metadata limit." >&2
  exit 1
fi

if grep -Eq '\|[[:space:]]*tee[[:space:]]+"\$\{INSTALLER_CONSOLE_LOG\}"' "${ROOT_DIR}/scripts/bootstrap_lakehouse_vm.sh"; then
  echo "The Peak Gear installer must not use a tee pipeline because long-lived Podman helpers can keep it open." >&2
  exit 1
fi

if ! grep -Eq '>[[:space:]]*"\$\{INSTALLER_CONSOLE_LOG\}"[[:space:]]+2>&1' "${ROOT_DIR}/scripts/bootstrap_lakehouse_vm.sh"; then
  echo "The Peak Gear installer must redirect output directly to its console log." >&2
  exit 1
fi

if ! grep -Fq 'ORACLE_USER_PWD: ${ORACLE_USER_PWD:-oracle}' "${ROOT_DIR}/scripts/bootstrap_lakehouse_vm.sh"; then
  echo "The Peak Gear bootstrap must provide the database password expected by current ORDS images." >&2
  exit 1
fi

if ! grep -Fq 'SC_SECURITY_CTX package and body must both be valid' "${ROOT_DIR}/scripts/bootstrap_lakehouse_vm.sh"; then
  echo "The Peak Gear bootstrap must verify the database security context package." >&2
  exit 1
fi

if ! grep -Fq "index(\$0, end) { exit }" "${ROOT_DIR}/scripts/bootstrap_lakehouse_vm.sh" \
    || ! grep -Fq -- '-- AUDIT POLICY (Unified Auditing)' "${ROOT_DIR}/scripts/bootstrap_lakehouse_vm.sh"; then
  echo "The Peak Gear ADB security bootstrap must omit unsupported unified-audit policy creation." >&2
  exit 1
fi

startup_helper="$({
  sed -n \
    '/cat > "${OPC_HOME}\/init\/start-application-services.sh" <<'\''EOF'\''/,/^EOF$/p' \
    "${ROOT_DIR}/scripts/bootstrap_lakehouse_vm.sh"
} || true)"
if [[ -z "${startup_helper}" ]]; then
  echo "Unable to locate the generated Peak Gear service startup helper." >&2
  exit 1
fi

startup_contract=(
  '/home/opc/init/setenv.sh'
  'source /home/opc/ingestion/.env'
  'systemctl --user start adb-wallet.service'
  '/home/opc/ingestion/.adb_load_done'
  '/home/opc/init/ensure-security-schema.sh'
  '/home/opc/ingestion/.security_schema_done'
  'build_service_image gravitino'
  'up --no-deps -d gravitino'
  'build_service_image ggsa'
  'systemctl --user start user-podman.service'
)
previous_line=0
for step in "${startup_contract[@]}"; do
  line="$(grep -nF -- "${step}" <<<"${startup_helper}" | head -n 1 | cut -d: -f1)"
  if [[ -z "${line}" ]]; then
    echo "Peak Gear service startup helper is missing required step: ${step}" >&2
    exit 1
  fi
  if (( line <= previous_line )); then
    echo "Peak Gear service startup helper has an invalid dependency order at: ${step}" >&2
    exit 1
  fi
  previous_line="${line}"
done

(
  cd "${ROOT_DIR}"
  zip -qr "${OUTPUT_ZIP}" . \
    -x '.terraform/*' \
    -x '.terraform.lock.hcl' \
    -x '.terraform.tfstate.lock.info' \
    -x '.oci/*' \
    -x '*/.oci/*' \
    -x 'dist/*' \
    -x '*/.DS_Store' \
    -x '*.tfstate' \
    -x '*.tfstate.*' \
    -x '*.tfplan' \
    -x '*.tfvars' \
    -x '*.tfvars.json' \
    -x 'crash.log' \
    -x 'crash.*.log' \
    -x '*.generated.zip' \
    -x '*wallet*.zip' \
    -x '*wallet*.b64' \
    -x '*.pem' \
    -x '*.key' \
    -x '*.p12' \
    -x '*.pfx' \
    -x '*.jks' \
    -x '.env' \
    -x '*/.env'
)

unzip -tq "${OUTPUT_ZIP}" >/dev/null

if unzip -Z1 "${OUTPUT_ZIP}" | grep -Eq '(^\.terraform/|(^|/)\.terraform\.tfstate\.lock\.info$|(^|/)\.oci/|^dist/|(^|/)\.DS_Store$|\.tfstate(\.|$)|\.tfplan$|\.tfvars(\.json)?$|(^|/)crash(\..*)?\.log$|\.generated\.zip$|wallet.*\.(zip|b64)$|\.pem$|\.key$|\.(p12|pfx|jks)$|(^|/)\.env$)'; then
  echo "Refusing to release an archive containing a generated, local, or sensitive artifact." >&2
  rm -f "${OUTPUT_ZIP}"
  exit 1
fi

required_entries=(
  'approved-artifacts.json'
  'artifacts.tf'
  'schema.yaml'
  'versions.tf'
  'main.tf'
  'variables.tf'
  'cloud-init/app.yaml'
  'scripts/bootstrap_lakehouse_vm.sh'
  'scripts/wait_for_bootstrap_callback.sh'
)

for required_entry in "${required_entries[@]}"; do
  if ! unzip -Z1 "${OUTPUT_ZIP}" | grep -Fxq "${required_entry}"; then
    echo "Resource Manager archive is missing required entry: ${required_entry}" >&2
    rm -f "${OUTPUT_ZIP}"
    exit 1
  fi
done

echo "Created and verified ${OUTPUT_ZIP}"
